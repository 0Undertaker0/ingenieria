package com.example.reservas20;

public class Usuario {
    private String imagen_perfil;
    private String nombre;
    private String carnet;

    public String getImagenPerfil() {
        return imagen_perfil;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCarnet() {
        return carnet;
    }
}
